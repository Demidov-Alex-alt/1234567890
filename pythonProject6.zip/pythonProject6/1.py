import calendar

is_leap = calendar.isleap(2027)

weekday = calendar.weekday(1995, 6, 25)

calendar2023 = calendar.calendar(2023)

# пример
print(calendar2023)
