from fuzzywuzzy import fuzz
dir(fuzz)

string1 = 'Плохой код на самом деле не плохой.'
string2 = 'Его просто не так поняли.'

ratio1 = fuzz.ratio(string1, string2)
print(f"Индекс схожести первой пары строк: {ratio1}")

string3 = 'Работает? Не трогай.'
string4 = 'Работает? Не трогай.'

ratio2 = fuzz.ratio(string3, string4)
print(f"Индекс схожести второй пары строк: {ratio2}")

string5 = 'Работает? Не трогай.'
string6 = 'Работает? Не трогай! скинь чистым кодом'

ratio3 = fuzz.ratio(string5, string6)
print(f"Индекс схожести третьей пары строк: {ratio3}")